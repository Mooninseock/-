class Student: #Student라는 클래스 생성
    def __init__(self): #객체를 초기화 해주는 함수.
        self.hakbunlist=[] 
        self.namelist=[]
        self.korlist=[]
        self.englist=[]
        self.mathlist=[]
        self.totallist =[]
        self.avglist = []
        self.hakjumlist = []

        
    def readList(self): #readList 함수 선언.
        self.hakbunlist = []
        self.namelist = []
        self.korlist = []
        self.englist = []
        self.mathlist = []
        flag = True
        print("프로그램을 종료하려면 학번에 '0'을 입력하시오")
        while flag:
            hakbun = input("학번을 입력하시오: ")
            if hakbun == '0':
                flag = False
            else :
                name = input("이름을 입력하시오: ")
                kor = int(input("국어점수를 입력하시오: "))
                eng = int(input("영어점수를 입력하시오: "))
                math = int(input("수학점수를 입력하시오: "))
                self.hakbunlist.append(hakbun) #학번리스트에 입력한 학번 추가
                self.namelist.append(name)     #이름리스트에 입력한 이름 추가
                self.korlist.append(kor)       #국어점수리스트에 입력한 국어점수 추가
                self.englist.append(eng)       #영어점수리스트에 입력한 영어점수 추가
                self.mathlist.append(math)     #수학점수리스트에 입력한 수학점수 추가


    def calList(self): #calList 함수 선언
        self.totlist = []
        self.avglist = []
        self.haksjumlist = []
        totlist = 0
        avg=0.0
        for i in range(len(self.korlist)):
            total = self.korlist[i] + self.englist[i] + self.mathlist[i] #총 학점을 구하는 식
            avg = total / 3.0 #평균을 구하는 식
            self.totlist.append(total)
            self.avglist.append(avg)
            #평균 점수를 바탕으로 학점 구하기
            if avg >= 90:
                grade = 'A'
            elif avg >= 80:
                grade = 'B'
            elif avg >= 70:
                grade = 'C'
            elif avg >= 60:
                grade = 'D'
            else:
                grade = 'F'
            self.haksjumlist.append(grade)

    
    def printList(self): #printList 함수 선언
        print("=" * 70)
        print("  번호\t\t  이름\t\t국어\t\t영어\t\t수학\t\t총점\t\t평균\t\t학점")
        print("=" * 70)
        for i in range(len(self.hakbunlist)):
            print("%3s\t%5s\t%3d\t\t%3d\t\t%3d\t\t%3d\t\t%.2f\t\t%s"%(self.hakbunlist[i],self.namelist[i], self.korlist[i],self.englist[i], self.mathlist[i], self.totlist[i], self.avglist[i], self.haksjumlist[i]))

            
myStudent = Student() #Student 클래스를 myStudent로 불러옴
myStudent.readList() #Student 클래스에 있는 readList 함수 실행
myStudent.calList() #Student 클래스에 있는 calList 함수 실행
myStudent.printList() #Student 클래스에 있는 printList 함수 실행
