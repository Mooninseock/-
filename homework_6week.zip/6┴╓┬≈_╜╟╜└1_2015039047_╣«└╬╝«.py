#실습1

number1 = int(input("첫번째 정수 : "))
number2 = int(input("두번째 정수 : "))
calculate = input("연산자 : ")
answer =0
if calculate=='+':
    answer = number1+number2
    print(number1,"+",number2,"=",answer)
elif calculate =='-':
    answer = number1-number2
    print(number1,"-",number2,"=",answer)
elif calculate=='*':
    answer = number1*number2
    print(number1,"*",number2,"=",answer)
elif calculate=='//':
    answer = number1 // number2
    print(number1,"//",number2,"=",answer)
elif calculate=='%':
    answer = number1%number2
    print(number1,"%",number2,"=",answer)
