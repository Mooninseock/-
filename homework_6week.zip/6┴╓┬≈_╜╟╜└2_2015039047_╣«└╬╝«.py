#실습2
number = int(input("번호 : "))
korea_score = int (input("국어 점수 : "))
english_score = int (input("영어 점수 :"))
math_score = int (input("수학 점수 :"))
science_score = int (input("물리 점수 :"))
sum = korea_score+english_score+math_score+science_score
average = sum / 4.0
grade=""
if average >= 90:
    grade = 'A'
elif average >=80:
    grade = 'B'
elif average >=70:
    grade = 'C'
elif average >=60:
    grade = 'D'
else:
    grade = 'F'
    
print("============================================================")
print("번호   국어   영어   수학   물리   총점    평균     학점")
print("============================================================")
print(number, end="     ")
print(korea_score, end="     ")
print(english_score, end="     ")
print(math_score, end="     ")
print(science_score, end="     ")
print(sum, end="     ")
print(average, end="     ")
print(grade, end="     ")
